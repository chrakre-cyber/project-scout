# ECON-004-FIX1 — rettingspakke (status: REVIEW, ikke DONE)

Retter de fire P2-funnene i den uavhengige reviewen av `f12d44a399509d97f2d353c147609825c1536329`.
**Rettingscommit:** `cefe290b598d55e3a2f25ca5be0b985a573b0fce` (gren `claude/wonderful-bardeen-yussx3`). Reviewet commit er forelder-kjeden `f12d44a`.

| # | Funn | Retting (`src/domain/economics/landed-cost.ts`, `types.ts`) |
|---|---|---|
| 1 | Falsk nedre grense ved ukjent drivlinje (437 500 > mulig 379 248) | Ukjent drivlinje beholder `no_exemption`/`with_exemption`; nedre grense bruker laveste mulige mva. (362 500). Uttrykkelig `not_applicable` gir full mva. som oppgitt. |
| 2 | Sen avrundingslikhet i øvrige kostnader ga `value` | Tie etter VAT-steget gir `rounding_tie_unresolved` i `missing`; totalene blir `lower_bound` (laveste kandidat, 458 725; kandidater 3/2 vises). |
| 3 | Eksplisitt `assumed_default` ga `validated` | Alle `AmountInput` med basis `assumed_default` gir estimatårsak `assumed_default_amount` (ny). |
| 4 | `source.kind = fixture` uten `fixtureOnly` omgikk testflagget | `fixtureOnly` ELLER `source.kind = fixture` krever `allowFixtureFxQuotes`; manglende/ugyldig `source` avvises. |

Uendret: avgiftsmotoren (`diff/tax-engine-diff.txt` er tom), ECON-002-godkjenninger, åpne kildepunkter (U-003, U-008, U-013, R-IMP-VAT-002/-003, R-DED-001), ECON-003-fixtureforventninger.

## Innhold
- `diff/f12d44a..cefe290.patch`, `stat.txt`, `tax-engine-diff.txt` (tom = avgiftsmotor byte-lik)
- `src/domain/economics/` (endret kode), `tests/economics-review-regressions.test.ts` (nye: reviewerens 4 + 6 skjerpede + egenskapstest), `tests/economics-core.test.ts` (uendret)
- `reviews/ECON-004.md` (§3b), `DECISIONS.md`, `MVP_BACKLOG.md`
- `results/`: kjøringer før og etter, `MANIFEST.json`/`MANIFEST.sha256`

## Resultater (faktisk kjørt)
- **Før** (kode fra f12d44a + nye regresjoner): 10 røde av 55 (`results/BEFORE-...`) — de fire reviewer-testene, fem skjerpede og egenskapstesten.
- **Etter** (cefe290): regresjonene + core + ECON-003-fixturetester: 3 filer / 75 tester grønne.
- **Fullt repo**: 37 filer / 856 tester grønne; `tsc --noEmit`, `eslint .`, `docs/tax/check-docs.mjs` rene.
- Ikke kjørt: build, e2e, DB.

## Kjøring (i repoet)
`npx vitest run tests/economics-review-regressions.test.ts tests/economics-core.test.ts tests/econ-golden-fixtures.test.ts`

Forventninger er uavhengig håndregnet (350 000 + 12 500 = 362 500; 100 000 + 25 000 + 333 723 + 2 = 458 725) og ikke justert mot koden. Egenskapstesten krever ≥ 18 faktiske sammenligninger (ikke-tomhetsvern; 18 er det observerte antallet, alle bestått).
