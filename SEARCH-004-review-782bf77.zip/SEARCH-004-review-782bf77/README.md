# SEARCH-004 — review-pakke (sluttcommit 782bf77, base 70f2d90)
Status REVIEW. Kandidatadapter NormalizedListing → CandidateV2.
Innhold: adapter (src/adapters/search-candidate/), tester (tests/search-candidate-adapter.test.ts), fixturer og avhengigheter (src/domain, src/adapters/search-prototype, src/providers/marketplace med de uendrede syntetiske annonsene, tests/fixtures, prototypens data.js/logic.js), rapport reviews/SEARCH-004.md, backlogg, patch fra 70f2d90, diffstat, changed-files, test-result.txt og MANIFEST.json (SHA-256 for alle filer unntatt manifestet selv).
Ikke inkludert: node_modules, .next, .env*, sertifikater, secrets, review-ZIP-er.
Kontroll i repoet: npx tsc --noEmit; npx eslint .; npx vitest run; npm run build.
