# SEARCH-005-FIX1 — ikke mist kostnadsvalg ved lagring

Codex har kontrollert SEARCH-005. Status fortsatt REVIEW. Appen og hosted database hos Christian er ikke endret. Ingen ny hovedoppgave skal startes.

## Kontrollgrunnlag

- ZIP SHA-256 stemmer: 25a93e437ee0bee0661e858089bd28f7812c1144d866e994b4b7051145563e71.
- Alle 272 manifestoppføringer finnes med korrekt hash.
- 540 av 540 leverte ikke-DB-tester består i separat Windows-kontrollkopi.
- Kildegjennomgang av ny migrasjon, serverlag, FormData-parser, forhåndsvisning, sider og skjema. Tre leverte skjermbilder er sett (desktop GLS, demoresultater og mobilskjema); dette er ikke Codex sin egen nettleserkjøring.
- Codex har ikke etterkjørt DB-/RLS-tester, Auth/PostgREST, nettleser-e2e, typecheck/lint/bygg. Claudes 83 DB-tester er belegg for isolert PostgreSQL, og nettleserbelegget bruker emulator. De kan ikke omtales som test mot faktisk Supabase.

## F1 P2 — ufullstendig egen kostnadslinje blir stille utelatt

src/server/search-form.ts i parseSearchFormValues avgjør `touched` bare ut fra id, beskrivelse og beløp. Dermed blir en rad med bare endret valuta, valgt mva.-grunnlag eller «Inngår i budsjettet» regnet som urørt og hoppet over. Lagringen lykkes og valgene kommer ikke med i dokumentet. Ukjent beløp med valgt valuta er et uttrykkelig produktkrav; det må ikke falle bort.

To uavhengige reproduksjoner med ellers gyldig demo-bmw-skjema:

1. custom.0.label='', custom.0.amount='', custom.0.currency='EUR'. Lagringen godtas; forvent feltfeil på manglende beskrivelse og ingen gyldig spec/JSON.
2. custom.0.label='', custom.0.amount='', custom.0.currency='NOK', custom.0.vat='incl', custom.0.included='true'. Samme feil.

De to vedlagte Codex-testene er kjørt og feiler på leveransen (r.ok er true, forvent false). Bruk dem uendret som regresjoner.

### Forventet retting

- Helt urørt tom rad med standard NOK, ikke oppgitt mva. og ingen inkludering kan fortsatt utelates uten feil.
- En rad med meningsfulle valg/innhold må enten bevares komplett eller gi tydelig feltfeil, eksempelvis «Gi kostnadslinjen en beskrivelse». Ikke finn på navn eller 0-beløp.
- Beskrevet rad med tomt beløp og EUR skal fortsatt bevares som ukjent EUR, med mva./budsjettvalg og stabil id.
- Uttrykkelig «Fjern linjen» skal fortsatt fjerne raden selv om gamle feltverdier følger med. Ikke ødelegg stabiliteten i lagrede id-er eller omrekkefølge.
- Ved avvist lagring beholdes alle råverdier, inkludert valuta/mva./budsjettvalg, så brukeren kan fullføre raden.
- Kjør en faktisk nettleserregresjon for disse valgene (dokumenter emulator dersom det er det som er tilgjengelig): fyll ellers gyldig skjema → velg EUR i tom egen rad → lagre → feil ved beskrivelse uten tap av EUR → skriv beskrivelse → lagre/gjenåpne → ukjent EUR bevart. Ta også med inkludering/mva. uten beskrivelse.

Vurder samtidig om faste kostnadsrader lar brukeren skrive beløp eller velge «Inngår i budsjettet» mens radens bruksavkrysning er av, og dermed mister verdiene uten klar beskjed. Dette er samme risiko, men en uttrykkelig deaktivering av en tidligere linje må fortsatt være mulig. Vis hvordan UI-et gjør bruk/utelatelse forståelig; ikke endre budsjettsemantikken eller autoøk budsjettgrensen.

## Grenser og leveranse

Kontroller faktisk kodebase/HEAD for SEARCH-005 (implementasjon 11d6543, senere rapport/ZIP). Bevar øvrig leveranse, migrasjon og dokumenthistorikk. Ingen hosted/lokal appoppdatering, publisering, nye pakker, avgiftsmotor eller utvidelse av databaseomfanget.

Bevar eksisterende tester og legg til de to regresjonene samt relevante grense-/nettleserkontroller. Kjør typecheck, lint, ikke-DB-tester og bygg. Isolerte DB-tester gjentas bare dersom DB-relatert kode endres eller nye funn gjør det nødvendig; ikke reset noen eksisterende database. Merk fortsatt manglende kontroll mot faktisk Supabase som gjenstående før lokal/hosted anvendelse, ikke som løst av emulator.

Oppdater reviews/SEARCH-005.md med rettingen og faktisk belegg, backloggens logg og lokal filplan ved endrede hashverdier. Lever komplett review-ZIP med kilde, tester, relevante screenshots, rapport, diff fra den faktisk vurderte SEARCH-005-basen, changed-files, manifest og ZIP-hash. Kontroller nødvendige uendrede testavhengigheter. Stopp på REVIEW for Codex.
