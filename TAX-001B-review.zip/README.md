# TAX-001B review-ZIP
Base (faktisk HEAD før oppdraget): b6cd8f0 · kode/dokument-commit: 88d0b04 · gren claude/wonderful-bardeen-yussx3.
Kun dokumentasjon (docs/tax, reviews, spec/decision/backlog). Les reviews/TAX-001B.md først.
Konklusjon: F1 og F2 rettet, 6 kilder lest (E1), 0 godkjente parametere, 0 klasse 1-referanser; beregningsgrunnlaget er fortsatt ufullstendig (stortingsvedtak, forskrift, tollkurs, kalkulator mangler).
Originale kildefiler er IKKE duplisert; kildepakkens hasher ligger i kildepakke-MANIFEST.json og docs/tax/sources.json.
Kjørt: node docs/tax/check-docs.mjs --pack <kildepakke> + 8 negative prøver (check-docs-output.txt). Ingen kodekontroller kjørt (ingen kode endret). Kalkulator ikke kjørt.
Patch: diff.patch (git apply fra base).
