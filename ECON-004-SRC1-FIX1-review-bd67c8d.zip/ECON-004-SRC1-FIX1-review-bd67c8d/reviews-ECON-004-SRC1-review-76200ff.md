# ECON-004 SRC1 — uavhengig rettingsreview

Reviewet commit: `76200ffc08646482cbe97503090a64c0dc9de6af`.

Konklusjon: to P2-funn. ECON-004 bør forbli REVIEW til de er rettet og kontrollert. Ingen regler eller økonomiflagg er godkjent av reviewen.

## P2-1: Akseptdatoens status kontrolleres bare når en tollkurs kontrolleres

`src/domain/economics/landed-cost.ts:127–132`, samt NOK-grenen ved 239 og fallback ved 255.

Registrering av `customs_acceptance_date_unknown` og `customs_acceptance_date_expected` skjer i `checkQuote` for tollkursen. NOK trenger ingen omregning og kaller ikke funksjonen. Kursfallback fra anskaffelseskursen kaller heller ikke funksjonen for tollrollen.

Reprodusert med dokumenterte avgiftsinput og syntetisk godkjent økonomiprofil:

- NOK uten akseptdato: `validated`, ingen estimat-/ufullstendighetsårsak.
- NOK med `expected_scenario`: `validated`, ingen estimatårsak for dato.
- EUR med fallback og manglende dato: bare `estimate` for kursfallback, ingen manglende-dato-årsak.
- Samme EUR-input med direkte tollkurs og manglende dato: korrekt `incomplete`.

Dette bryter kontrakten om at ukjent akseptdato er ufullstendig og forventet dato er scenario. Datoen gjelder også avgiftsregimets tidfesting; behovet for den forsvinner ikke med NOK-pris. Dagens alle-false-profil hindrer `validated`, men NOK/fallback gir likevel feil status/årsaker allerede nå.

Rett statusregistreringen ved behandling av `customsDate`, uavhengig av kursgren. Behold periodekontrollen i tollkursvalideringen og unngå dupliserte årsaker. Faktisk oppgitt dato skal fortsatt kunne bestå; forventet dato skal beholde egen årsak også uten kursperiode.

## P2-2: Ukjent mva-håndtering lager et scenario som motsier akseptert fradragsrett

`src/domain/economics/landed-cost.ts:397–405`; sammenlign eksplisitt konsistenssperre i samme funksjon.

Med `deduction = recoverable` fra `dealer_profile` og ukjent `vatHandling` returneres både registrert rapportering og `not_registered_pays_at_import`, samtidig som fradragsretten beholdes. Et eksplisitt input med nettopp kombinasjonen ikke registrert + recoverable blokkeres derimot med `inconsistent_vat_status`.

Reprodusert: scenarioet for ikke-registrert importør angir 25 000 kr betalt ved import, mens resultatet fortsatt har akseptert `recoverable`. Ingen rad merker at den krever endret fradragsforutsetning. Resultatet er riktignok `incomplete`, men de strukturerte scenarioene motsier funksjonens egen konsistensregel.

Filtrer bort uforenlige scenarioer uten å markere faktisk registrering som bekreftet. Alternativt må felles scenarioer uttrykkelig ha egne konsistente forutsetninger for både håndtering og fradrag. Ukjent håndtering skal fortsatt være ukjent/ufullstendig, og ved ukjent fradragsrett kan begge håndteringskanaler fortsatt undersøkes.

## Kontrollert uten nye funn i de avgrensede prøvene

- Råkurs 1/100 normaliseres én gang, og normalisert NOK-per-enhet-format fungerer.
- Transport etter innførselsstedet påvirker kostnad, mens transport til stedet og lasting påvirker både kostnad og mva.-grunnlag uten dobbelttelling i de undersøkte prøvene.
- Ukjent/suspendert kurs gir nedgradering/ufullstendighet, og suspendert kurs brukes ikke.
- Brutto er skilt fra mva.-betalingskanal; ingen totalpost utgis som kontant ved grensen.
- Elbilkvalifikasjon og grunnlag behandles som avgrensede scenarioer. Denne reviewen godkjenner ikke `vehicle_price_only` som rettsregel.

## Faktisk utført og begrensninger

- Alle 51 oppføringer i reviewpakkens manifest kontrollert mot størrelse og SHA-256; commit-ID stemmer.
- Pakkens Python Decimal-kontroll kjørt: 25 kontroller bestått. Dette er utviklerens kontrollskript, ikke et nytt uavhengig forfattet orakel.
- Egen kjøring av den leverte kjernen via Nodes TypeScript-stripping: 11 diagnostiske input og 17 beståtte kontrollpåstander. Funnene er observert direkte i resultatene, ikke bare antatt fra kodelesing. Diagnostiske ekstraeksempler er ikke alle klassifisert som feil.
- Fire foreslåtte regresjonstester er levert separat. De er ikke kjørt med Vitest her; motsvarende input er kjørt i egen harness og viser feilene. De må kjøres i fullt repo etter retting.
- Ikke kjørt: hele Vitest-suiten, typecheck, lint, check-docs, build, e2e eller DB. Utviklerens 885 tester er ikke et reviewerresultat.
- De utelatte kildeoriginalene er ikke kontrollert som repoarkiv i denne pakken. Dette er en kode-/kontraktreview, ikke en ny full juridisk review eller fullstendig kildearkivrevisjon.

Ingen produksjonskode eller test i reviewpakken er endret. Reviewartefaktene ligger separat.
