# ECON-004-SRC1-FIX1 — rettingspakke (status: REVIEW, ikke DONE)

**Kode-commit:** `bd67c8d3c10ca69015b8e50757f8b583180ce6d4` (gren `claude/wonderful-bardeen-yussx3`). Reviewet: `76200ffc08646482cbe97503090a64c0dc9de6af`. Eksport med `git archive`. **Økonomiflaggene er fortsatt `false`; ingen regel/parameter er godkjent; avgiftsmotor, ECON-003-fixturer og kildearkiv er uendret (`diff/tax-engine-fixtures-archive-diff.txt` er tom); U-013 åpen; ECON-005 ikke startet.**

## Funn og retting
| # | Funn | Retting |
|---|---|---|
| P2-1 | Akseptdatoens status (ukjent/forventet) ble bare registrert i tollkursvalideringen, så NOK og kursfallback manglet den | Registreres i hovedflyten uavhengig av valuta og kursgren; periodekontrollen er beholdt i tollkursgrenen; én årsak per kall |
| P2-2 | Ukjent `vatHandling` ga «ikke registrert»-scenario selv med akseptert `recoverable` | «Ikke registrert» filtreres bort ved `recoverable` og oppgis i `importVatSettlement.excludedScenarios`; håndteringen forblir `unknown`/`accepted:false`/`vat_handling_unknown`; status `scenarios` også med én rad; registrering utledes ikke |

## Innhold
`reviews-ECON-004-SRC1-review-76200ff.md` (reviewerens rapport), `reviews/ECON-004-SRC1-retting.md` (rettingsrapport), `src/domain/economics/`, `tests/economics-src1-review-regressions.test.ts` (reviewerens 4 + 4 utvidelser), `tests/economics-source-driven.test.ts`/`economics-core`/`economics-review-regressions` (to små tilpasninger, se rapporten), `docs/econ/landed-cost-core.md`, `diff/`, `results/`, `MANIFEST.*`.

## Kontroller (faktisk kjørt)
- Fullt repo: 39 filer / **893 tester bestått**; `tsc --noEmit` exit 0; `eslint .` exit 0; `check-docs` OK (`results/`). Økonomi-testene: 112 bestått.
- Mot forrige kode (76200ff) med de nye regresjonene: 7 av 8 feiler som forventet (`results/BEFORE-76200ff-med-nye-regresjoner.txt`); etter retting består alle 8.
- Ikke kjørt: build, e2e, DB. Pakken er ikke kjørt frittstående (ingen `node_modules`/kildearkiv); kjør i repoet: `npx vitest run tests/economics-src1-review-regressions.test.ts tests/economics-source-driven.test.ts tests/economics-core.test.ts tests/economics-review-regressions.test.ts tests/econ-golden-fixtures.test.ts`.
