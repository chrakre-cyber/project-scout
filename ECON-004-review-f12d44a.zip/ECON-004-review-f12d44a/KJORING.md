# ECON-004 reviewpakke — kjørebeskrivelse

**Commit:** `f12d44a399509d97f2d353c147609825c1536329` (gren `claude/wonderful-bardeen-yussx3`). Basis: ECON-003 sluttcommit `9ad2cbd52a7241122be49d106eaafd91c695bd4c`. Status: REVIEW (ikke DONE). Pakken er eksportert med `git archive` av commiten, ikke fra arbeidskopi.

## Innhold
- `src/domain/economics/` (ny) og `src/domain/tax/` (uendret fra ECON-002/003)
- `tests/economics-core.test.ts` (44 tester), ECON-003-regresjon `tests/econ-golden-fixtures.test.ts`, fixturer `tests/fixtures/{econ-golden,econ-arithmetic,tax-golden,tax-calculator-observations}.ts`, samt `tests/tax-vehicle-profiles.test.ts` og `tests/econ-002-review-regressions.test.ts`
- `reviews/` (ECON-004 inkl. gapvurdering, ECON-001/-002/-003 og ECON-003-review), `IMPORT_ENGINE_SPEC.md`, `ARCHITECTURE.md`, `DECISIONS.md`, `MVP_BACKLOG.md`, `CLAUDE.md`, `docs/econ/`, `docs/tax/{rules,sources,references,profiles}.json`, `profiles.md`, `purchase-basis.md`, `TAX-001A-rules.md`, `primarkilder/MANIFEST.md`, `check-docs.mjs`
- `diff/` : hele diffen `9ad2cbd..f12d44a` (`*.patch`), `stat.txt`, `commits.txt`
- `repro/` : reproduksjoner (se under) og `expected-output.txt` (utskrift fra min kjøring)
- `package.json`, `package-lock.json`, `tsconfig.json`, `vitest.config.ts`, `eslint.config.mjs`
- `MANIFEST.json` / `MANIFEST.sha256`: SHA-256 og størrelse for alle andre filer

**Ikke med (bevisst):** primærkilde-HTML, kalkulatorskjermbilder og `node_modules`. To eksisterende testfiler (`tax-engine.test.ts`, `tax-calculator-observations.test.ts`) leser dem og er derfor utelatt; de er uendret i repoet. `check-docs.mjs` er med, men trenger de utelatte filene og kjører bare i full repo.

## Kjøring
```
npm ci
npx tsc --noEmit
npx vitest run                                        # 4 filer i pakken
npx vitest run --config repro/vitest.repro.config.ts  # reproduksjonene, med utskrift
```
Kontrollert i pakken (med node_modules lenket fra repoet): `tsc` ren; `vitest run` 4 filer bestått; repro 20 tester bestått. I fullt repo: 36 filer / 845 tester, typecheck, eslint og check-docs rene (bekreftet på nytt). ESLint er ikke kjørt på selve pakken.

## Reproduksjoner (`repro/econ-004.repro.test.ts`)
1. Ukjent transport/forsikring, elbilfritak, fradragsstatus — blokk 1a–1c
2. Avrundingslikhet og kandidatbeløp — blokk 2a (mva. 300 002 → 1 / 0), 2b (kjøpesum x,5)
3. Manglende tollkurs, uttrykkelig fallback, fixture-kurs uten testflagg — 3a–3c
4. Estimert (diesel, forhandleroppgitt vekt) og blokkert (bensin) engangsavgift — 4a–4b
5. Validated-forsøk med flagg true — 5a–5c. **Merk:** 5b viser at `validated` ER oppnåelig når alle fire økonomiflagg og godkjent avrunding er satt, avgiftsmotoren gir `calculated` (dokumentert vekt, dagpresis dato) og ingen estimatårsaker finnes. 5a viser at dagens avgiftsinput (forhandleroppgitt vekt) holder resultatet på `estimate`. Flaggene er `false` i registeret.
6. Null, negative og for store beløp — blokk 6
Alle input er syntetiske/fixture; ingen kurs er offisiell.
