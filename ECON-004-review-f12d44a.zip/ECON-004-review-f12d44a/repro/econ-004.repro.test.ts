/**
 * ECON-004 — reproduksjoner for reviewer. Hver blokk skriver ut det relevante resultatet (console.log) og har enkle kontroller (expect) som ikke
 * er laget for å "passe" koden: de gjengir det review skal vurdere. Ingen ekte kurser eller kjøretøyopplysninger; alt er syntetisk/fixture.
 * Kjør: npx vitest run --config repro/vitest.repro.config.ts
 */
import { describe, expect, it } from "vitest";
import { calculateEconomics, UNCONFIRMED_HALF_UP, type EconomicsConfig, type EconomicsInput, type EconomicsProfile, type FxQuote } from "@/domain/economics";
import { NO_OTA_2026_A_PB, type TaxInput } from "@/domain/tax";
import { ECON_CASES, FIXTURE_FX } from "../tests/fixtures/econ-golden";

const show = (title: string, r: ReturnType<typeof calculateEconomics>, extra: Record<string, unknown> = {}) => {
  const slim = {
    status: r.status, blockers: r.blockers.map((b) => b.code), estimateReasons: r.estimateReasons, incompleteReasons: r.incompleteReasons,
    warnings: r.warnings, roundingTies: r.roundingTies, transportNok: r.transportNok, insuranceNok: r.insuranceNok, customsValueNok: r.customsValueNok,
    importVat: r.importVat, tax: { status: r.tax.status, engine: r.tax.engineStatus, total: r.tax.totalRegistrationTaxesNok, estimateReasons: r.tax.estimateReasons, blockers: r.tax.blockers },
    fx: { acquisition: r.fx.acquisition.status, customs: r.fx.customs.status, customsRate: r.fx.customs.rate },
    importCashRequirement: r.importCashRequirement, estimatedLandedCost: r.estimatedLandedCost, vatRecoverability: r.vatRecoverability, ...extra,
  };
  console.log(`\n=== ${title} ===\n${JSON.stringify(slim, (_k, v) => (typeof v === "bigint" ? `${v}n` : v), 2)}`);
};

const fxq = (rate: string, over: Partial<FxQuote> = {}): FxQuote => ({ pair: "EUR/NOK", rate, source: { kind: "fixture" }, effectiveAt: null, quotedAt: null, fixtureOnly: true, ...over });
const cfg = (over: Partial<EconomicsConfig> = {}): EconomicsConfig => ({ rounding: UNCONFIRMED_HALF_UP, allowFixtureFxQuotes: true, ...over });
const EXCL = { state: "excluded_by_scenario", reason: "repro" } as const;
const BEV = ECON_CASES[1]!.golden.input; // CASE-002 (elbil), testinput
const DIE = ECON_CASES[2]!.golden.input; // CASE-003 (diesel), testinput
const nok = (price: string, taxInput: TaxInput, over: Partial<EconomicsInput> = {}): EconomicsInput => ({
  price: { currency: "NOK", advertisedNet: price, priceBasis: "net", use: "advertised", evidence: "dealer_entered" }, fx: {}, taxInput,
  transport: { amount: "0", basis: "quoted" }, insurance: { amount: "0", basis: "scenario_assumption" }, charges: { climateGas: EXCL, registrationFee: EXCL, customsDuty: EXCL },
  deduction: { value: "non_recoverable", source: { kind: "dealer_entered" } }, evExemption: "applies", asOf: "2026-10-18", ...over,
});
const eur = (taxInput: TaxInput, over: Partial<EconomicsInput> = {}): EconomicsInput => ({
  ...nok("1", taxInput), price: { currency: "EUR", advertisedNet: "38562", priceBasis: "net", use: "advertised", evidence: "dealer_entered" },
  fx: { acquisition: fxq(FIXTURE_FX.rate), customs: fxq(FIXTURE_FX.rate) }, ...over,
});

describe("1. Ukjent transport/forsikring, elbilfritak og fradragsstatus", () => {
  it("1a alt ukjent (standard): nedre grense, ufullstendig, ingen enkeltstående økonomisk kost", () => {
    const r = calculateEconomics(nok("350000", BEV, { transport: undefined, insurance: undefined, evExemption: undefined, deduction: undefined }), cfg());
    show("1a transport, forsikring, elbilfritak og fradrag ukjent", r);
    expect(r.status).toBe("incomplete");
    expect(r.importCashRequirement.kind).toBe("lower_bound");
    expect(r.estimatedLandedCost.kind).toBe("lower_bound");
    expect(r.transportNok).toBeNull();
    expect(r.insuranceNok).toBeNull();
  });
  it("1b transport/forsikring oppgitt, men fritak og fradrag ukjent: scenarier (2 kontant, 4 kost), ingen enkeltverdi", () => {
    const r = calculateEconomics(nok("350000", BEV, { evExemption: undefined, deduction: undefined }), cfg());
    show("1b elbilfritak og fradrag ukjent", r);
    expect(r.importCashRequirement).toMatchObject({ kind: "scenarios", valueNok: null });
    expect(r.estimatedLandedCost).toMatchObject({ kind: "scenarios", valueNok: null });
    expect((r.estimatedLandedCost as { scenarios: unknown[] }).scenarios).toHaveLength(4);
  });
  it("1c fradragsstatus fra annonsetekst/antakelse ignoreres; dealer_entered godtas; kontantbehov uendret", () => {
    const listing = calculateEconomics(nok("350000", BEV, { deduction: { value: "recoverable", source: { kind: "listing_claim" } } }), cfg());
    show("1c fradrag fra annonse (ignorert)", listing);
    expect(listing.vatRecoverability.accepted).toBe(false);
    expect(listing.estimatedLandedCost.kind).toBe("scenarios");
    const dealer = calculateEconomics(nok("350000", BEV, { deduction: { value: "recoverable", source: { kind: "dealer_entered" } } }), cfg());
    show("1c fradrag dealer_entered = recoverable", dealer);
    expect(dealer.vatRecoverability.accepted).toBe(true);
    expect(dealer.importCashRequirement).toEqual(listing.importCashRequirement);
  });
});

describe("2. Avrundingslikhet og kandidatbeløp", () => {
  it("300 002 NOK (EV, fritak antatt): 25 % × 2 = 0,5 ⇒ likhet; nedre grense 0, kandidater 1 (half_up) / 0 (half_even)", () => {
    const r = calculateEconomics(nok("300002", BEV), cfg());
    show("2a mva.-likhet", r);
    expect(r.roundingTies[0]).toContain("1 (half_up) / 0 (half_even)");
    expect(r.importVat.status).toBe("lower_bound");
    expect(r.status).toBe("incomplete");
    for (const [price, vat] of [["300001", 0n], ["300003", 1n]] as const) expect(calculateEconomics(nok(price, BEV), cfg()).importVat.valueNok).toBe(vat);
  });
  it("kjøpesum x,5 ved kursomregning (1000 × 10,4995 = 10 499,5)", () => {
    const r = calculateEconomics(eur(DIE, { price: { currency: "EUR", advertisedNet: "1000", priceBasis: "net", use: "advertised", evidence: "dealer_entered" }, fx: { acquisition: fxq("10.4995"), customs: fxq("10") } }), cfg());
    show("2b kjøpesum-likhet", r, { acquisitionUsedNok: r.acquisition.acquisitionUsedNok, acquisitionUsedRaw: r.acquisition.acquisitionUsedRaw });
    expect(r.roundingTies.join(" ")).toContain("kjøpesum (anskaffelseskurs)");
    expect(r.importCashRequirement.kind).toBe("lower_bound");
  });
});

describe("3. Manglende tollkurs og uttrykkelig fallback", () => {
  it("3a manglende tollkurs: ikke stilltiende lik anskaffelseskurs", () => {
    const r = calculateEconomics(eur(DIE, { fx: { acquisition: fxq(FIXTURE_FX.rate) } }), cfg());
    show("3a tollkurs mangler", r);
    expect(r.fx.customs.status).toBe("not_calculated");
    expect(r.importVat.status).toBe("not_calculated");
    expect(r.incompleteReasons).toContain("customs_fx_missing");
  });
  it("3b uttrykkelig fallback ⇒ estimat med egen årsak", () => {
    const r = calculateEconomics(eur(DIE, { fx: { acquisition: fxq(FIXTURE_FX.rate), customsFallback: "use_acquisition_rate_assumed" } }), cfg());
    show("3b fallback", r);
    expect(r.fx.customs.status).toBe("assumed_from_acquisition");
    expect(r.estimateReasons).toContain("customs_fx_fallback_acquisition_rate");
  });
  it("3c fixture-kurs uten testflagg avvises", () => {
    const r = calculateEconomics(eur(DIE), { rounding: UNCONFIRMED_HALF_UP });
    show("3c fixture-kurs uten testflagg", r);
    expect(r.status).toBe("blocked");
  });
});

describe("4. Estimert eller blokkert engangsavgift", () => {
  it("4a diesel med forhandleroppgitt vekt: avgiften er estimat ⇒ hele resultatet er estimat/ufullstendig, aldri validert", () => {
    const r = calculateEconomics(nok("100000", DIE, { evExemption: "not_applicable" }), cfg());
    show("4a avgift estimat", r);
    expect(r.tax.status).toBe("estimate");
    expect(r.estimateReasons).toContain("tax_estimate");
    expect(r.status).not.toBe("validated");
  });
  it("4b bensin (utenfor støttet profil): avgift blokkert ⇒ ingen avgift i summen, nedre grense", () => {
    const petrol: TaxInput = { ...DIE, propulsion: { ...DIE.propulsion, combustionFuel: "petrol" } };
    const r = calculateEconomics(nok("100000", petrol, { evExemption: "not_applicable" }), cfg());
    show("4b avgift blokkert", r);
    expect(r.tax.status).toBe("blocked");
    expect(r.importCashRequirement.kind).toBe("lower_bound");
    expect(r.incompleteReasons).toContain("tax_blocked");
  });
});

describe("5. Forsøk på validated med godkjenningsflagg = true", () => {
  const all: EconomicsProfile = { vatRulesApproved: true, roundingApproved: true, customsFxRuleApproved: true, deductionRuleApproved: true };
  const approvedRounding = { mode: "half_up", status: "approved" } as const;
  const clean = (taxInput: TaxInput) => nok("100000", taxInput, {
    evExemption: "not_applicable", transport: { amount: "8000", basis: "quoted" }, insurance: { amount: "500", basis: "quoted" },
    deduction: { value: "non_recoverable", source: { kind: "dealer_profile" } },
    charges: { climateGas: { state: "not_applicable", basis: "repro" }, registrationFee: { amount: "0", basis: "quoted" }, customsDuty: { state: "not_applicable", basis: "repro" } },
  });
  it("5a alle flagg true, men avgiftsmotoren gir estimat (forhandleroppgitt vekt) ⇒ estimate, ikke validated", () => {
    const r = calculateEconomics(clean(DIE), cfg({ profile: all, rounding: approvedRounding }));
    show("5a flagg true, avgift estimat", r);
    expect(r.status).toBe("estimate");
  });
  it("5b alle flagg true + avgift approved (dokumentert vekt, dagpresis første registrering) ⇒ status", () => {
    const documented: TaxInput = { ...DIE, norwegianTaxWeight: { kg: 1976, basis: "vehicle_register" }, firstRegistration: { precision: "day", value: "2023-11-15" } };
    const r = calculateEconomics(clean(documented), cfg({ profile: all, rounding: approvedRounding }));
    show("5b flagg true, avgift approved?", r);
    console.log("tax.status =", r.tax.status, "| tax.estimateReasons =", r.tax.estimateReasons, "| economics.status =", r.status);
    // Observert utfall: validated ER oppnåelig når alle fire økonomi-flagg + godkjent avrunding er satt OG avgiftsmotoren gir `calculated`
    // (godkjent profil, dokumentert vekt, dagpresis dato) OG ingen estimat-/scenarioårsaker finnes. Flaggene er false i registeret.
    expect(r.tax.status).toBe("approved");
    expect(r.estimateReasons).toEqual([]);
    expect(r.status).toBe("validated");
  });
  it("5c registerprofil (alle flagg false) gir aldri validated, uansett ellers ren input", () => {
    const documented: TaxInput = { ...DIE, norwegianTaxWeight: { kg: 1976, basis: "vehicle_register" }, firstRegistration: { precision: "day", value: "2023-11-15" } };
    const r = calculateEconomics(clean(documented), cfg({ rounding: approvedRounding }));
    show("5c registerprofil", r);
    expect(r.status).not.toBe("validated");
  });
});

describe("6. Null, negative og for store beløp", () => {
  const cases: Array<[string, string]> = [["0", "pris 0"], ["-1", "negativ"], ["1000000001", "over grensen"], ["1e5", "eksponent"], ["1,5", "komma"], ["", "tom"]];
  it.each(cases)("pris «%s» (%s) ⇒ blokkert uten totaler", (v) => {
    const r = calculateEconomics(nok(v, DIE), cfg());
    show(`6 pris «${v}»`, r);
    expect(r.status).toBe("blocked");
    expect(r.importCashRequirement.kind).toBe("not_calculated");
  });
  it("transport -5 / 1000000001 blokkeres; transport 0 er gyldig når den er oppgitt; 1 000 000 000 regnes eksakt", () => {
    expect(calculateEconomics(nok("1000", DIE, { transport: { amount: "-5", basis: "quoted" } }), cfg()).status).toBe("blocked");
    const big = calculateEconomics(nok("1000", DIE, { transport: { amount: "1000000001", basis: "quoted" } }), cfg());
    show("6 transport over grensen", big);
    expect(big.blockers[0]!.code).toBe("amount_out_of_range");
    expect(calculateEconomics(nok("1000", DIE, { transport: { amount: "0", basis: "quoted" } }), cfg()).status).not.toBe("blocked");
    const max = calculateEconomics(nok("1000000000", DIE, { transport: { amount: "0", basis: "quoted" }, evExemption: "not_applicable" }), cfg());
    show("6 pris = 1 000 000 000", max);
    expect(max.importVat.valueNok).toBe(250000000n);
  });
});

void NO_OTA_2026_A_PB;
