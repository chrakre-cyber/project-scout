# SEARCH-005 review-ZIP
Base 8401dea → HEAD 3430238 (branch claude/wonderful-bardeen-yussx3). Les reviews/SEARCH-005.md (også i snapshot/reviews/) først: avvik og IKKE-kjørte kontroller står øverst.
- snapshot/ : komplett kildetre for HEAD (uten node_modules, .next, ZIP-er, PDF). Kjør `npm ci` og deretter kontrollene.
- diff-from-8401dea.patch, diffstat.txt, changed-files.txt : presis endring fra base.
- SEARCH-005-file-plan.json : selektiv lokal filplan med forventede lokale hasher (aldri blind overskriving).
- Kontroller (fra snapshot/): npx tsc --noEmit; npx eslint .; npx vitest run; npm run build;
  bash scripts/test-db-isolated.sh tests/db/search-drafts.test.ts tests/db/qa-catalog.test.ts; bash scripts/test-db-mutations.sh; bash scripts/test-e2e-search005.sh (krever Playwright/Chromium, PostgreSQL-binærer).
- Logger og skjermbilder: snapshot/reviews/SEARCH-005/{logs,screenshots}.
