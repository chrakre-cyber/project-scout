"""Uavhengig kontroll av literalene i tests/economics-source-driven.test.ts (Python Decimal; ingen kode fra repoet). Kjør: python3 -I repro/independent-check.py"""
from decimal import Decimal as D, ROUND_HALF_UP
def r(x): return int(x.quantize(D(1), rounding=ROUND_HALF_UP))
ok = True
def check(name, got, exp):
    global ok
    good = got == exp; ok &= good
    print(("PASS " if good else "FAIL ") + name, got, "" if good else f"(forventet {exp})")
tax_diesel = 333723
# 1. mva-håndtering, NOK 100 000 + transport 8 000
check("CV", 100000 + 8000, 108000)
check("VAT 25 %", r(D(108000) * D("0.25")), 27000)
check("brutto = 468 723", 100000 + 8000 + 27000 + tax_diesel, 468723)
check("landed recoverable = 441 723", 100000 + 8000 + tax_diesel, 441723)
# 2. EUR 38 562 til tollkurs 10,817 (enhet 1) + transport 8 000
purchase = D(38562) * D("10.817"); check("kjøpesum tollkurs råverdi", purchase, D("417125.154"))
cv = r(purchase) + 8000; check("tollverdi", cv, 425125)
check("mva.", r(D(cv) * D("0.25")), 106281)  # 106 281,25
check("anskaffelse 38 562 × 10,6709", r(D(38562) * D("10.6709")), 411491)
# 3. råkurs / enhet
check("SEK 95,550/100", D("95.550") / 100, D("0.9555")); check("10 000 SEK", r(D(10000) * D("0.9555")), 9555)
check("JPY 6,059/100", D("6.059") / 100, D("0.06059")); check("1 000 000 JPY", r(D(1000000) * D("0.06059")), 60590)
check("10.12345678/100", D("10.12345678") / 100, D("0.1012345678"))
# 4. transportsplit: pris 100 000, til grensen 8 000, etter 3 000, forsikring 200, lasting 500
cv = 100000 + 8000 + 200 + 500; vat = r(D(cv) * D("0.25"))
check("tollverdi (uten transport etter grensen)", cv, 108700); check("mva. 27 175", vat, 27175)
check("total 472 598", 100000 + 8000 + 3000 + 200 + 500 + vat + tax_diesel, 472598)
check("total uten etter-grensen = 469 598", 100000 + 8000 + 200 + 500 + vat + tax_diesel, 469598)
# 5. elbil
for price, e in ((299999, 0), (300000, 0), (300001, 0), (300003, 1), (350000, 12500)):
    check(f"EV {price} (tollverdi-grunnlag, transport 0)", r(D(max(0, price - 300000)) * D("0.25")), e)
for price in (295000,):
    cv = price + 8000
    check("EV 295 000+8 000, grunnlag tollverdi", r(D(max(0, cv - min(300000, cv))) * D("0.25")), 750)
    check("EV 295 000+8 000, grunnlag kjøretøypris", r(D(max(0, cv - min(300000, price))) * D("0.25")), 2000)
check("EV 350 000+8 000 begge grunnlag", r(D(358000 - 300000) * D("0.25")), 14500)
print("ALLE BESTÅTT" if ok else "AVVIK"); raise SystemExit(0 if ok else 1)
