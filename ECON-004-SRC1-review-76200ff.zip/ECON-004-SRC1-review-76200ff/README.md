# ECON-004-SRC1 — reviewpakke (kildejustering). Status: REVIEW, ikke DONE

**Kode-commit:** `76200ffc08646482cbe97503090a64c0dc9de6af` (gren `claude/wonderful-bardeen-yussx3`). Forrige reviewet punkt: `494251acaeac34bc818ce8dc40a0aedd3e9550dd` (kildevurdering). Eksport med `git archive` av commiten. **Alle fire økonomiflagg er fortsatt `false`, ingen regel/parameter er godkjent, U-013 er åpen, ECON-002 og ECON-003 er uendret, ECON-005 er ikke startet.**

## Innhold
- `reviews/ECON-004-kildejustering.md` (endringsrapport, kontraktendringer, samlet kildebehov), `ECON-004-kildevurdering.md`, `ECON-004.md`, `ECON-004-FIX1-review-cefe290.md`
- `src/domain/economics/` (endret), `src/domain/tax/` (uendret; se `diff/tax-engine-and-econ003-fixtures-diff.txt` = tom)
- `tests/economics-source-driven.test.ts` (29 nye), `economics-core.test.ts` og `economics-review-regressions.test.ts` (tilpasset feltnavn; ingen forventet beløp endret), `econ-golden-fixtures.test.ts` + `tests/fixtures/` (ECON-003, uendret)
- `docs/econ/landed-cost-core.md` (feltenes betydning), `docs/tax/sources.json` + `rules.json` (T53–T69, gjenbrukte T23/T24/T35/T36, `sourceReview`), `docs/tax/check-docs.mjs`
- `docs/tax/primarkilder/econ004/ARCHIVE-README.md`, `PACK-MANIFEST.json`, `ACQUISITION.json` — **selve arkivet (20 MB originalfiler) er i repoet på commiten og er utelatt her**; hashene er i manifestet og kontrolleres av `economics-source-driven.test.ts` (kapittel 7)
- `diff/` (patch uten arkivfilene, stat, tom avgiftsmotor-/fixturediff), `results/`, `repro/independent-check.py`, `MANIFEST.json`/`MANIFEST.sha256`

## Kontroller (faktisk kjørt)
- Fullt repo: `npx vitest run` → 38 filer, **885 tester bestått**; `npm run typecheck`, `npx eslint .`, `node docs/tax/check-docs.mjs`: rene (`results/`). Økonomi-testene alene: 104 enkelttester bestått (`results/vitest-economics-verbose.txt`).
- `repro/independent-check.py`: 25 uavhengige Decimal-kontroller bestått (`results/independent-check.txt`).
- Ikke kjørt: build, e2e, DB. Pakken er ikke kjørt som frittstående prosjekt (den mangler `node_modules` og arkivet); kjør i repoet på commiten: `npx vitest run tests/economics-source-driven.test.ts tests/economics-core.test.ts tests/economics-review-regressions.test.ts tests/econ-golden-fixtures.test.ts`.

## Forslag til reviewfokus
1. Kontraktbrudd og at ingen forventet beløp er endret (`diff/…patch`, test-diffene).
2. `vatHandling` vs `deduction` (blokkering av selvmotsigelse; ukjent ⇒ scenarier; brutto uendret).
3. Akseptdato/kursperiode (fremtidige perioder tillatt; utenfor periode blokkert; suspensjon ukjent ⇒ estimat).
4. Råkurs/enhet normalisert én gang (inkl. `rate`+`raw` konsistens).
5. Transport før/etter innførselsstedet og at 8 000 bare er en uttrykkelig konfigurert antakelse.
6. Elbilkvalifikasjon vs drivlinje; målegrunnlag velges ikke; scenarioaritmetikken for `vehicle_price_only`.
7. Kildepåstandene i `sources.json` (`supportedClaims`/`limitations`) mot kildene — er noe påstått som ikke er dekket?
